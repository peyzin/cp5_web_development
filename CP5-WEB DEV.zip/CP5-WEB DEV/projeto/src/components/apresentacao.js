import './App.css';
import apresentacao from './components/apresentacao';

function App() {
  return (
    <div className="App">
 <div className="container">
      <h1>Benefícios do Nosso Aplicativo</h1>
      <div className="benefit-section">
        <div className="benefit">
          <img src="https://static.vecteezy.com/ti/vetor-gratis/p1/11568404-icone-de-entrega-rapida-conjunto-de-icones-premium-laranja-para-negocios-e-financas-eps-10-editavel-gratis-vetor.jpg" alt="Entrega Rápida" />
          <h2>Entrega Rápida</h2>
          <p>Com nossa tecnologia avançada de localização e parceiros dedicados, seu pedido chega até você em tempo recorde!</p>
        </div>

        <div className="benefit">
          <img src="https://img.icons8.com/ios-filled/100/000000/restaurant-building.png" alt="Variedade de Restaurantes" />
          <h2>Variedade de Restaurantes</h2>
          <p>Escolha entre centenas de restaurantes com cardápios diversificados, desde fast food até alta gastronomia.</p>
        </div>

        <div className="benefit">
          <img src="https://static.vecteezy.com/ti/vetor-gratis/p3/583889-de-icone-de-cartao-de-credito-gratis-vetor.jpg" alt="Pagamento Fácil" />
          <h2>Pagamento Fácil</h2>
          <p>Oferecemos várias opções de pagamento, como cartões de crédito, débito e carteiras digitais, tudo com um simples clique.</p>
        </div>
      </div>
    </div>
    <Apresentacao />
    </div>
  );
}

export default apresentacao;

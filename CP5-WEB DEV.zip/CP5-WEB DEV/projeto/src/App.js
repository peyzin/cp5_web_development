import './App.css';

function App() {
  return (
    <div className="App">
      <div>
        <h1>Descubra Comidas ao Seu Alcance</h1>
        <p>Encontre os melhores pratos da sua cidade com nosso aplicativo de comida. Baixe agora e tenha acesso a restaurantes incríveis e sabores inesquecíveis!</p>
        <button className="download-button">Baixar Agora</button>
      </div>
    </div>
  );
}

export default App;
